package com.cybage.dao;

import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;

@Service
public interface SuperAdminDAO {

	ModelAndView viewheldback(int invoiceId, ModelMap model);

}
