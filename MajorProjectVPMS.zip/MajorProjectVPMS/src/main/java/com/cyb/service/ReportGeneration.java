package com.cybage.service;


import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.TemporalType;

import org.springframework.web.servlet.ModelAndView;

import com.cybage.configuration.LoggerClass;
import com.cybage.model.Aggregateinvoiceinfo;
import com.cybage.model.Invoiceinfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

// TODO: Auto-generated Javadoc
/**
 * The Class ReportGeneration.
 */
public class ReportGeneration {
	
	/** The Constant logger. */
	static final LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	static org.apache.log4j.Logger logger = loggerInstance.logger;

	/**
	 * Gets the percent approved data.
	 *
	 * @param vendorCode the vendor code
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the percent approved data
	 * @throws JsonProcessingException the json processing exception
	 */
	@SuppressWarnings("unchecked")
	public static ModelAndView getPercentApprovedData(Date fromDate,Date toDate) throws JsonProcessingException{
		
		ArrayList<Aggregateinvoiceinfo> invoiceList;		
		HashMap<Integer,String> vendorName=new HashMap<Integer,String>();
		HashMap<Integer,Double> approvedCount=new HashMap<Integer,Double>();
		HashMap<Integer,Double> totalRecordCount=new HashMap<Integer,Double>();
		HashMap<Integer,Double> percentApproveCount=new HashMap<Integer,Double>();
		HashMap<Integer,Double> totalPaymentAmount=new HashMap<Integer,Double>();
		HashMap<Integer,Integer> vendorCodeMap=new HashMap<Integer,Integer>();

		ArrayList<String> vendorNameList = new ArrayList<String>();
		 ArrayList<Double> percentApproveList = new ArrayList<Double>(); 
		 ArrayList<Double> paymentList = new ArrayList<Double>(); 
		 ArrayList<Integer> vendorCodeList = new ArrayList<Integer>();
		ModelAndView modelObject=new ModelAndView("approvedCharts");
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		 
		 entityManagerObject.close();
		 
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  	Aggregateinvoiceinfo invoiceinfo = iterator.next();
		  	int vendorcode = invoiceinfo.getVendorCode(); 
		  	if(((invoiceinfo.getInvoiceStatus().equals("Approved"))||(invoiceinfo.getInvoiceStatus().equals("Heldback")))&&((!invoiceinfo.getPane().equals("Satisfied Exception Criteria")))){
				  	
		  		if(totalRecordCount.containsKey(vendorcode)){
		  			double totalCount = totalRecordCount.get(vendorcode);
			 		totalCount++;
					totalRecordCount.put(vendorcode,totalCount);
		  		}else{
				 totalRecordCount.put(vendorcode,(double) 1);
		  		}
		  		
		  	}
		 }
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if((((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Processed")))||(((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Unprocessed")))||(invoiceinfo.getPane().equals("Satisfied Exception Criteria"))){
	  	 		 	iterator.remove();
	  	 	    }
			}

		 
			 for(int i=0;i<invoiceList.size();i++){
				 Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(i);
				 int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 String name=aggregateinvoiceinfoObject.getVendorName();
				 if((!vendorName.containsKey(vendorcode))&&(aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Approved"))){
					 vendorName.put(vendorcode, name);
					 vendorCodeMap.put(vendorcode,aggregateinvoiceinfoObject.getVendorCode());
					 loggerInstance.logger.info("vendorName"+name);
				 }
				 if(aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Approved")){
					 double amount = aggregateinvoiceinfoObject.getPaymentAmount();
				if(approvedCount.containsKey(vendorcode)){
					double value = approvedCount.get(vendorcode);
					
					double previousAmount=totalPaymentAmount.get(vendorcode);
					amount=amount+previousAmount;
					
					value++;
					approvedCount.put(vendorcode, value);
					totalPaymentAmount.put(vendorcode, amount);
					
				}else{
					
					approvedCount.put(vendorcode,(double) 1);
					totalPaymentAmount.put(vendorcode,amount);
				}
				
				 }	
				
			 }
			
			 for(int i=0;i<invoiceList.size();i++){
				 Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(i);
				 int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 
				 if((aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Approved"))&& (!percentApproveCount.containsKey(vendorcode))){
				 
				 double totalRecordOfVendor = totalRecordCount.get(vendorcode);
				 double approvedRecordsOfVendor = approvedCount.get(vendorcode);
				 double percentageApprovedRequest = approvedRecordsOfVendor/totalRecordOfVendor * 100;
				 
				 loggerInstance.logger.info("VALUES FOR totalRecordOfVendor "+totalRecordOfVendor+" approvedRecordsOfVendor"+approvedRecordsOfVendor+" percentageApprovedRequest"+percentageApprovedRequest);
				
				 percentApproveCount.put(vendorcode,percentageApprovedRequest);
				 }
				 
			 }
			 
			 
			 loggerInstance.logger.info(approvedCount);
			 loggerInstance.logger.info(totalRecordCount);
			 loggerInstance.logger.info(percentApproveCount);
			 loggerInstance.logger.info(vendorName);
			 
			 Iterator vendorNameIterator = vendorName.entrySet().iterator();
			    while (vendorNameIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)vendorNameIterator.next();
			        String value = (String) pair.getValue();
			        vendorNameList.add(value);
			       logger.info("Name map"+pair.getKey() + " = " + pair.getValue());
			    }
			    Iterator percentApproveCountIterator = percentApproveCount.entrySet().iterator();
			    while (percentApproveCountIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)percentApproveCountIterator.next();
			        Double value = (Double) pair.getValue();
					percentApproveList.add(value);
			       logger.info("Percent="+pair.getKey() + " = " + pair.getValue());
			    }
			    Iterator totalPaymentAmountIterator = totalPaymentAmount.entrySet().iterator();
			    while (totalPaymentAmountIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)totalPaymentAmountIterator.next();
			        Double value = (Double) pair.getValue();
			        paymentList.add(value);
			       logger.info("Name map"+pair.getKey() + " = " + pair.getValue());
			    }
			    Iterator vendorCodeIterator = vendorCodeMap.entrySet().iterator();
			    while (vendorCodeIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)vendorCodeIterator.next();
			        Integer value = (Integer) pair.getValue();
			        vendorCodeList.add(value);
			       logger.info("Name map"+pair.getKey() + " = " + pair.getValue());
			    }
			    ObjectMapper objectMapper = new ObjectMapper();
		  	 	
		  	 	
	  	 	modelObject.addObject("vendorName",vendorNameList);
	  	 	modelObject.addObject("percentApproved",percentApproveList);
	  	 	modelObject.addObject("paymentList",paymentList);
	  	 	modelObject.addObject("vendorCodeList",vendorCodeList);
	  		modelObject.addObject("number",objectMapper.writeValueAsString("Percentage of Approved Request"));
	  		modelObject.addObject("title",objectMapper.writeValueAsString("Approve Request Report"));
	  		modelObject.addObject("type",objectMapper.writeValueAsString("bar"));

	  		modelObject.addObject("fromDate",fromDate);
	  		modelObject.addObject("toDate",toDate);
		 
		return modelObject;
		 
		 }
	
	/**
	 * Gets the percent heldback data.
	 *
	 * @param vendorCode the vendor code
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the percent heldback data
	 * @throws JsonProcessingException the json processing exception
	 */
	@SuppressWarnings("unchecked")
	public static ModelAndView getPercentHeldbackData(Date fromDate,Date toDate) throws JsonProcessingException{
		ArrayList<Aggregateinvoiceinfo> invoiceList;		
		HashMap<Integer,String> vendorName=new HashMap<Integer,String>();
		HashMap<Integer,Double> approvedCount=new HashMap<Integer,Double>();
		HashMap<Integer,Double> totalRecordCount=new HashMap<Integer,Double>();
		HashMap<Integer,Double> percentApproveCount=new HashMap<Integer,Double>();
		HashMap<Integer,Double> totalPaymentAmount=new HashMap<Integer,Double>();
		HashMap<Integer,Integer> vendorCodeMap=new HashMap<Integer,Integer>();
		ArrayList<Double> paymentList = new ArrayList<Double>(); 
		 ArrayList<Integer> vendorCodeList = new ArrayList<Integer>();
		ArrayList<String> vendorNameList = new ArrayList<String>();
		 ArrayList<Double> percentApproveList = new ArrayList<Double>(); 
		ModelAndView modelObject=new ModelAndView("heldbackCharts");
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		 entityManagerObject.close();
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
			  	Aggregateinvoiceinfo invoiceinfo = iterator.next();
			  	int vendorcode = invoiceinfo.getVendorCode(); 
			  	if(((invoiceinfo.getInvoiceStatus().equals("Approved"))||(invoiceinfo.getInvoiceStatus().equals("Heldback")))&&((!invoiceinfo.getPane().equals("Satisfied Exception Criteria")))){
					  	
			  		if(totalRecordCount.containsKey(vendorcode)){
			  			double totalCount = totalRecordCount.get(vendorcode);
				 		totalCount++;
						totalRecordCount.put(vendorcode,totalCount);
			  		}else{
					 totalRecordCount.put(vendorcode,(double) 1);
			  		}
			  		
			  	}
			 }
			 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
			  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
		  	 	 if((((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Processed")))||(((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Unprocessed")))||(invoiceinfo.getPane().equals("Satisfied Exception Criteria"))){
		  	 		 	iterator.remove();
		  	 	    }
				}

			 for(int i=0;i<invoiceList.size();i++){
				 Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(i);
				 int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 String name=aggregateinvoiceinfoObject.getVendorName();
				 if((!vendorName.containsKey(vendorcode))&&(aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Heldback"))){
					 vendorName.put(vendorcode, name);
					 vendorCodeMap.put(vendorcode,aggregateinvoiceinfoObject.getVendorCode());
					 logger.info("vendorName"+name);
				 }
				 if(aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Heldback")){
					 double amount = aggregateinvoiceinfoObject.getPaymentAmount();
						if(approvedCount.containsKey(vendorcode)){
							double value = approvedCount.get(vendorcode);
							
							double previousAmount=totalPaymentAmount.get(vendorcode);
							amount=amount+previousAmount;
							
							value++;
							approvedCount.put(vendorcode, value);
							totalPaymentAmount.put(vendorcode, amount);
							
						}else{
							
							approvedCount.put(vendorcode,(double) 1);
							totalPaymentAmount.put(vendorcode,amount);
						}
						
				 }				
			 }
			
			 for(int i=0;i<invoiceList.size();i++){
				 Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(i);
				 int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 
				 if((aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Heldback"))&& (!percentApproveCount.containsKey(vendorcode))){
				 
				 double totalRecordOfVendor = totalRecordCount.get(vendorcode);
				 double approvedRecordsOfVendor = approvedCount.get(vendorcode);
				 double percentageApprovedRequest = approvedRecordsOfVendor/totalRecordOfVendor * 100;
				 
				 loggerInstance.logger.info("VALUES FOR totalRecordOfVendor "+totalRecordOfVendor+" approvedRecordsOfVendor"+approvedRecordsOfVendor+" percentageApprovedRequest"+percentageApprovedRequest);
				
				 percentApproveCount.put(vendorcode,percentageApprovedRequest);
				 }
				 
			 }
			 
			 
			 loggerInstance.logger.info(approvedCount);
			 loggerInstance.logger.info(totalRecordCount);
			 loggerInstance.logger.info(percentApproveCount);
			 loggerInstance.logger.info(vendorName);
			 
			 Iterator vendorNameIterator = vendorName.entrySet().iterator();
			    while (vendorNameIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)vendorNameIterator.next();
			        String value = (String) pair.getValue();
			        vendorNameList.add(value);
			       logger.info("Name map"+pair.getKey() + " = " + pair.getValue());
			    }
			    Iterator percentApproveCountIterator = percentApproveCount.entrySet().iterator();
			    while (percentApproveCountIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)percentApproveCountIterator.next();
			        Double value = (Double) pair.getValue();
					percentApproveList.add(value);
			       logger.info("Percent="+pair.getKey() + " = " + pair.getValue());
			    }
			    Iterator totalPaymentAmountIterator = totalPaymentAmount.entrySet().iterator();
			    while (totalPaymentAmountIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)totalPaymentAmountIterator.next();
			        Double value = (Double) pair.getValue();
			        paymentList.add(value);
			       logger.info("Name map"+pair.getKey() + " = " + pair.getValue());
			    }
			    Iterator vendorCodeIterator = vendorCodeMap.entrySet().iterator();
			    while (vendorCodeIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)vendorCodeIterator.next();
			        Integer value = (Integer) pair.getValue();
			        vendorCodeList.add(value);
			       logger.info("Name map"+pair.getKey() + " = " + pair.getValue());
			    }
			    ObjectMapper objectMapper = new ObjectMapper();
		  	 	
			    modelObject.addObject("vendorName",vendorNameList);
		  	 	modelObject.addObject("percentApproved",percentApproveList);
		  	 	modelObject.addObject("paymentList",paymentList);
		  	 	modelObject.addObject("vendorCodeList",vendorCodeList);
	  	 	modelObject.addObject("number",objectMapper.writeValueAsString("Percentage of Heldback Request"));
	  		modelObject.addObject("title",objectMapper.writeValueAsString("Heldback Request Report"));
	  		modelObject.addObject("type",objectMapper.writeValueAsString("bar"));

	  		modelObject.addObject("fromDate",fromDate);
	  		modelObject.addObject("toDate",toDate);
		 
		return modelObject;
		 
		
	}
	
	/**
	 * Gets the percent payment data.
	 *
	 * @param vendorCode the vendor code
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the percent payment data
	 * @throws JsonProcessingException the json processing exception
	 */
	@SuppressWarnings("unchecked")
	public static ModelAndView getPercentPaymentData(Date fromDate, Date toDate) throws JsonProcessingException {
		
		ArrayList<Aggregateinvoiceinfo> invoiceList;		
		HashMap<Integer,String> vendorName=new HashMap<Integer,String>();
		HashMap<Integer,Double> paymentMap=new HashMap<Integer,Double>();
		HashMap<Integer,Integer> vendorCodeMap=new HashMap<Integer,Integer>();
		
		ArrayList<String> vendorNameList = new ArrayList<String>();
		ArrayList<Double> paymentList = new ArrayList<Double>(); 
		 ArrayList<Integer> vendorCodeList = new ArrayList<Integer>();
			
		 ModelAndView modelObject=new ModelAndView("paymentCharts");
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		
		 entityManagerObject.close();
		 
	
			for(int index=0;index<invoiceList.size();index++){
				Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(index);
				if(aggregateinvoiceinfoObject.getInvoiceStatus().equals("Approved")){
				int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 String name=aggregateinvoiceinfoObject.getVendorName();
				 
				 if(!vendorName.containsKey(vendorcode)){
					 vendorName.put(vendorcode, name);
					 vendorCodeMap.put(vendorcode,aggregateinvoiceinfoObject.getVendorCode());
				 }
				 
				 if(paymentMap.containsKey(vendorcode)){
					 double paymentAmount = paymentMap.get(vendorcode);
					 paymentAmount = paymentAmount+aggregateinvoiceinfoObject.getPaymentAmount();
					 paymentMap.put(vendorcode, paymentAmount);
				 }
				 else{
					 paymentMap.put(vendorcode, (double)aggregateinvoiceinfoObject.getPaymentAmount());
				 }
				}
			}
			Iterator vendorNameIterator = vendorName.entrySet().iterator();
		    while (vendorNameIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)vendorNameIterator.next();
		        String value = (String) pair.getValue();
		        vendorNameList.add(value);
		       logger.info(pair.getKey() + " = " + pair.getValue());
		    }
			
		    Iterator paymentAmountIterator = paymentMap.entrySet().iterator();
		    while (paymentAmountIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)paymentAmountIterator.next();
		        
		        Double value = (Double) pair.getValue();
		        paymentList.add(value);
		       logger.info(pair.getKey() + " = " + pair.getValue());
		    }		    
		    Iterator vendorCodeIterator = vendorCodeMap.entrySet().iterator();
		    while (vendorCodeIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)vendorCodeIterator.next();
		        Integer value = (Integer) pair.getValue();
		        vendorCodeList.add(value);
		       logger.info("Name map"+pair.getKey() + " = " + pair.getValue());
		    }
		    ObjectMapper objectMapper = new ObjectMapper();
		    	 	
		    modelObject.addObject("vendorName",vendorNameList);	  	 	
	  	 	modelObject.addObject("paymentList",paymentList);
	  	 	modelObject.addObject("vendorCodeList",vendorCodeList);
	  
		  	 modelObject.addObject("number",objectMapper.writeValueAsString("Percentage of Total Payment Request"));
		  	 modelObject.addObject("title",objectMapper.writeValueAsString("Total Payment Request Report"));
		  	 modelObject.addObject("type",objectMapper.writeValueAsString("bar"));

		  	modelObject.addObject("fromDate",fromDate);
	  		modelObject.addObject("toDate",toDate);
		
  	 	return modelObject;	
	}
	
	//Exceptional criteria function.
	
	@SuppressWarnings("unchecked")
	public static ModelAndView getExceptionalReport(Date fromDate, Date toDate) throws JsonProcessingException {
		
		ArrayList<Aggregateinvoiceinfo> invoiceList;		
		HashMap<Integer,String> vendorName=new HashMap<Integer,String>();
		HashMap<Integer,Double> paymentApprovedMap=new HashMap<Integer,Double>();
		HashMap<Integer,Double> paymentHeldbackMap=new HashMap<Integer,Double>();
		HashMap<Integer,Double> paymentRejectedMap=new HashMap<Integer,Double>();
		HashMap<Integer,Integer> vendorCodeMap=new HashMap<Integer,Integer>();
		
		
		ArrayList<String> vendorNameList = new ArrayList<String>();
		ArrayList<Double> paymentApprovedList = new ArrayList<Double>(); 
		ArrayList<Double> paymentHeldbackList = new ArrayList<Double>(); 
		ArrayList<Double> paymentRejectedList = new ArrayList<Double>(); 
		ArrayList<Integer> vendorCodeList = new ArrayList<Integer>();
		 ModelAndView modelObject=new ModelAndView("ExceptionalCharts");
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		
		 entityManagerObject.close();
		 logger.info("invoice "+invoiceList.size());
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if(!invoiceinfo.getPane().equals("Satisfied Exception Criteria")){
	  	 		 	iterator.remove();
	  	 	    }
	  	 	 else if(invoiceinfo.getInvoiceStatus().equals("Processed")){
	  	 		 	iterator.remove();
	  	 	    }
			}
		
			
			for(int index=0;index<invoiceList.size();index++){
				Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(index);
				int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				if(aggregateinvoiceinfoObject.getInvoiceStatus().equals("Approved")){				
				 String name=aggregateinvoiceinfoObject.getVendorName();				 
				 if(!vendorName.containsKey(vendorcode)){
					 vendorName.put(vendorcode, name);
					 vendorCodeMap.put(vendorcode,aggregateinvoiceinfoObject.getVendorCode());
				 }
				 
				 if(paymentApprovedMap.containsKey(vendorcode)){
					 double paymentAmount = paymentApprovedMap.get(vendorcode);
					
					 paymentAmount = paymentAmount+aggregateinvoiceinfoObject.getPaymentAmount();
					 paymentApprovedMap.put(vendorcode, paymentAmount);
				 }
				 else{
					 paymentApprovedMap.put(vendorcode, (double)aggregateinvoiceinfoObject.getPaymentAmount());
				 }
				}	
				else{
					 if(!paymentApprovedMap.containsKey(vendorcode)){
						 paymentApprovedMap.put(vendorcode, (double)0);
					 }					 
				}
				if(aggregateinvoiceinfoObject.getInvoiceStatus().equals("Heldback")){
					
					 String name=aggregateinvoiceinfoObject.getVendorName();
					 
					 if(!vendorName.containsKey(vendorcode)){
						 vendorName.put(vendorcode, name);
						 vendorCodeMap.put(vendorcode,aggregateinvoiceinfoObject.getVendorCode());
					 }
					 
					 if(paymentHeldbackMap.containsKey(vendorcode)){
						 double paymentAmount = paymentHeldbackMap.get(vendorcode);
						 paymentAmount = paymentAmount+aggregateinvoiceinfoObject.getPaymentAmount();
						 paymentHeldbackMap.put(vendorcode, paymentAmount);
					 }
					 else{
						 paymentHeldbackMap.put(vendorcode, (double)aggregateinvoiceinfoObject.getPaymentAmount());
					 }
					}
				else{
					 if(!paymentHeldbackMap.containsKey(vendorcode)){
						 paymentHeldbackMap.put(vendorcode, (double)0);
					 }	 
				}
				// reject
				if(paymentRejectedMap.containsKey(vendorcode)){
					 double paymentAmount = paymentRejectedMap.get(vendorcode);
					 paymentAmount = paymentAmount+aggregateinvoiceinfoObject.getPendingPayment();
					 paymentRejectedMap.put(vendorcode, paymentAmount);
				 }
				 else{
					 paymentRejectedMap.put(vendorcode, (double)aggregateinvoiceinfoObject.getPendingPayment());
				 }
			}
		
			
			Iterator vendorNameIterator = vendorName.entrySet().iterator();
		    while (vendorNameIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)vendorNameIterator.next();
		        String value = (String) pair.getValue();
		        vendorNameList.add(value);
		       logger.info(pair.getKey() + " = " + pair.getValue());
		    }
			
		    Iterator paymentAmountIterator = paymentApprovedMap.entrySet().iterator();
		    while (paymentAmountIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)paymentAmountIterator.next();
		        
		        Double value = (Double) pair.getValue();
		        paymentApprovedList.add(value);
		       logger.info("Approved"+pair.getKey() + " = " + pair.getValue());
		    }
		    
		    Iterator paymentHeldbackAmountIterator = paymentHeldbackMap.entrySet().iterator();
		    while (paymentHeldbackAmountIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)paymentHeldbackAmountIterator.next();
		        
		        Double value = (Double) pair.getValue();
		        paymentHeldbackList.add(value);
		       logger.info("Heldback"+pair.getKey() + " = " + pair.getValue());
		    }
		    Iterator paymentRejectedAmountIterator = paymentRejectedMap.entrySet().iterator();
		    while (paymentRejectedAmountIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)paymentRejectedAmountIterator.next();
		        
		        Double value = (Double) pair.getValue();
		        paymentRejectedList.add(value);
		       logger.info("rejected"+pair.getKey() + " = " + pair.getValue());
		    }
		    Iterator vendorCodeIterator = vendorCodeMap.entrySet().iterator();
		    while (vendorCodeIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)vendorCodeIterator.next();
		        Integer value = (Integer) pair.getValue();
		        vendorCodeList.add(value);
		       logger.info("Name map"+pair.getKey() + " = " + pair.getValue());
		    }
		    
		    
		  	 //result.addObject("list", objectMapper.writeValueAsString(list));  	 	
	  	
		    modelObject.addObject("vendorName",vendorNameList);	  	
	  	 	modelObject.addObject("vendorCodeList",vendorCodeList);	  
	   	 	modelObject.addObject("percentApproved",paymentApprovedList);
	   	 	modelObject.addObject("paymentHeldback",paymentHeldbackList);
	   	 	modelObject.addObject("paymentRejected",paymentRejectedList);
	   	
	   	 	
	   	 	
		  	modelObject.addObject("fromDate",fromDate);
	  		modelObject.addObject("toDate",toDate);
		
  	 	return modelObject;	
	}

@SuppressWarnings("unchecked")
public static ModelAndView getMonthlyPayment() {
		
		ArrayList<Aggregateinvoiceinfo> invoiceList;		
		HashMap<Integer,String> vendorName=new HashMap<Integer,String>();
		HashMap<Integer,Double> paymentMap=new HashMap<Integer,Double>();
		HashMap<Integer,Integer> vendorCodeMap=new HashMap<Integer,Integer>();

		ArrayList<String> vendorNameList = new ArrayList<String>();
		ArrayList<Double> paymentList = new ArrayList<Double>();
		ArrayList<Integer> vendorCodeList = new ArrayList<Integer>();
		ModelAndView modelObject=new ModelAndView("superAdminReport");
		EntityManager entityManagerObject=Database.getEntityManager();	
		int month=Calendar.getInstance().get(Calendar.MONTH)+1;		
		Date first=java.sql.Date.valueOf(LocalDate.now().with( TemporalAdjusters.firstDayOfMonth()).toString());
		Date last=java.sql.Date.valueOf(LocalDate.now().with( TemporalAdjusters.lastDayOfMonth()).toString());
		logger.info(month+"...."+first+"......"+last);
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", first, TemporalType.DATE)
         .setParameter("endDate", last, TemporalType.DATE)
         .getResultList();
		 
		 entityManagerObject.close();
		
		 //Removing entries which are not approved
  		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
  			Aggregateinvoiceinfo invoiceinfo = iterator.next();
  			 if((invoiceinfo.getInvoiceStatus().equals("Unprocessed"))||(invoiceinfo.getInvoiceStatus().equals("Processed"))||(invoiceinfo.getInvoiceStatus().equals("Heldback"))){
  				 iterator.remove();
  			 }
  		 }
  		 
		 for(int index=0;index<invoiceList.size();index++){
				Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(index);
				 int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 String name=aggregateinvoiceinfoObject.getVendorName();
				
				 if(!vendorName.containsKey(vendorcode)){
					 vendorName.put(vendorcode, name);
					 vendorCodeMap.put(vendorcode,aggregateinvoiceinfoObject.getVendorCode());

				 }
				 
				 if(paymentMap.containsKey(vendorcode)){
					 double paymentAmount = paymentMap.get(vendorcode);
					 paymentAmount = paymentAmount+aggregateinvoiceinfoObject.getPaymentAmount();
					 paymentMap.put(vendorcode, paymentAmount);
				 }
				 else{
					 paymentMap.put(vendorcode, (double)aggregateinvoiceinfoObject.getPaymentAmount());
				 }
			}
			Iterator vendorNameIterator = vendorName.entrySet().iterator();
		    while (vendorNameIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)vendorNameIterator.next();
		        String value = (String) pair.getValue();
		        vendorNameList.add(value);
		       /* vendorCodeList.add(pair.getKey()+"-"+value);*/
		       logger.info(pair.getKey() + " = " + pair.getValue());
		    }
			
		    Iterator paymentAmountIterator = paymentMap.entrySet().iterator();
		    while (paymentAmountIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)paymentAmountIterator.next();
		        
		        Double value = (Double) pair.getValue();
		        paymentList.add(value);
		       logger.info(pair.getKey() + " = " + pair.getValue());
		    }
		    Iterator vendorCodeIterator = vendorCodeMap.entrySet().iterator();
		    while (vendorCodeIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)vendorCodeIterator.next();
		        Integer value = (Integer) pair.getValue();
		        vendorCodeList.add(value);
		       logger.info("Name map"+pair.getKey() + " = " + pair.getValue());
		    }
		    
		    
		    ArrayList<String> vendorList=ReportGeneration.getVendorDetails();
			
		    ObjectMapper objectMapper = new ObjectMapper();
		    
		  	 try {
				modelObject.addObject("vendorName",vendorNameList);
				modelObject.addObject("vendorList",vendorList);		
				modelObject.addObject("vendorCodeList",vendorCodeList);	
				modelObject.addObject("percentApproved",paymentList);
				modelObject.addObject("number",objectMapper.writeValueAsString("Percentage of Total Payment Request"));
				modelObject.addObject("title",objectMapper.writeValueAsString("Total Payment Request Report"));
				modelObject.addObject("type",objectMapper.writeValueAsString("bar"));
				
				Calendar mCalendar = Calendar.getInstance();    
				String monthName = mCalendar.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());
				
				modelObject.addObject("currentMonth",monthName);
				
		  	} catch (JsonProcessingException e) {
				logger.error(e);
			}
		  	 
		return modelObject;
	}
	
@SuppressWarnings("unchecked")
public static ArrayList< String> getVendorDetails() {
		ArrayList<Aggregateinvoiceinfo> vendorDetails;		
	ArrayList<Integer> vendorIdList=new ArrayList<Integer>();
	ArrayList<String> vendorCodeList = new ArrayList<String>(); 
	EntityManager entityManagerObject=Database.getEntityManager();	
	
	
	vendorCodeList.add(0+"-"+"All Vendors");
	
	vendorDetails = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery
			("select s from Aggregateinvoiceinfo s").getResultList();
	
	for(int index=0;index<vendorDetails.size();index++){
		if(!vendorIdList.contains(vendorDetails.get(index).getVendorCode())){
			vendorIdList.add(vendorDetails.get(index).getVendorCode());
			vendorCodeList.add(vendorDetails.get(index).getVendorCode()+"-"+vendorDetails.get(index).getVendorName());
		}
	}
	entityManagerObject.close();		
	
	   return vendorCodeList;
}
}
