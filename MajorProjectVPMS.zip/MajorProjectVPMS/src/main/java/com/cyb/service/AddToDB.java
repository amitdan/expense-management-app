package com.cybage.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;

import javax.persistence.EntityManager;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.ModelMap;

import com.cybage.configuration.LoggerClass;
import com.cybage.configuration.PropertyClass;
import com.cybage.model.*;

// TODO: Auto-generated Javadoc
/**
 * The Class AddVendorToDB.
 */
public class AddToDB {

	/** The Constant logger. */
	private static final LoggerClass loggerInstance = LoggerClass
			.getLoggerInstance();

	/** The upload directory. */
	private static final String UPLOAD_DIRECTORY = System
			.getProperty("user.dir") + "\\Files\\";

	/**
	 * Adds the vendor to db.
	 * 
	 * @param filename
	 *            the filename
	 * @param model
	 *            the model
	 * @return the string
	 */
	@SuppressWarnings("unchecked")
	public String addExcelToDb(String filename, ModelMap model, String createdBy) {
		String excelFilePath = UPLOAD_DIRECTORY + filename + ".xlsx";
		FileInputStream inputStream = null;
		EntityManager entityManagerObject = Database.getEntityManager();
		String message = null;
		ArrayList<String> headerNames = ValidateExcelFile.getTableHeader();

		PropertyClass property;

		Connection connection = null;

		String queryPrefix = getQueryPrefix(headerNames);

		String queryPostfix = getQueryPostfix(headerNames.size());

		java.sql.PreparedStatement preparedStatement = null;

		HashMap<String, String> headerTypes = ValidateExcelFile
				.getHeaderTypesMap();

		try {
			inputStream = new FileInputStream(new File(excelFilePath));
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet firstSheet = workbook.getSheetAt(0);

			ArrayList<Integer> vendorList;
			ArrayList<Integer> vendorIdList = new ArrayList<Integer>();
			ArrayList<String> invoiceList;
			ArrayList<String> invoiceIdList = new ArrayList<String>();
			ArrayList<String> duplicateInvoiceList = new ArrayList<String>();

			HashMap<Integer, ArrayList<String>> vendorMap = new HashMap<Integer, ArrayList<String>>();
			HashMap<Integer, Double> vendorPaymentMap = new HashMap<Integer, Double>();
			HashMap<Integer, String> aggregateDescriptionMap = new HashMap<Integer, String>();
			HashMap<Integer, String> invoiceDataMap1 = new HashMap<Integer, String>();

			vendorList = (ArrayList<Integer>) entityManagerObject.createQuery(
					"select s.vendorCode from Vendorinfo s").getResultList();
			invoiceList = (ArrayList<String>) entityManagerObject.createQuery(
					"select s.invoice_Num from Invoiceinfo s").getResultList();

			Vendorinfo vendorinfo = new Vendorinfo();
			Invalidinvoiceinfo invalidinvoiceinfo = new Invalidinvoiceinfo();
			Aggregateinvoiceinfo aggregateinvoiceinfo = new Aggregateinvoiceinfo();
			int vendorCode;
			double payment;
			double payment1;
			String invoiceNum;
			String msg = "\n";

			property = new PropertyClass();
			Class.forName(property.getDatabaseDriver());
			connection = DriverManager.getConnection(
					property.getDatabaseConnectionURL(),
					property.getDatabaseUsername(),
					property.getDatabasePassword());

			preparedStatement = connection.prepareStatement(getQueryString(
					queryPrefix, queryPostfix));

			for (int i = 1; i <= firstSheet.getLastRowNum(); i++) {
				// get row data
				XSSFRow row = (XSSFRow) firstSheet.getRow(i);
				int cnt = headerNames.size();
				StringBuffer rowString = new StringBuffer();

				for (int index = 0; index < cnt; index++) {
					if (row.getCell(index) == null) {
						continue;
					} else {
						rowString.append(row.getCell(index).toString() + "::");
					}
				}
				if (rowString.toString().contains("STANDARD")) {
					String[] valueArray = rowString.toString().split("::");
					loggerInstance.logger.info("Size of value array = "
							+ valueArray.length);

					int headerCounter = 1;

					for (int looper = 0; looper < valueArray.length; looper++) {
						if (headerCounter > headerNames.size()) {
							headerCounter = 1;
						}

						String value = valueArray[looper];

						if (value.length() > 0) {
							String headerType = headerTypes.get(headerNames
									.get(looper));

							if (headerType.equalsIgnoreCase("DATE")) {
								java.sql.Date date = getSqlDate(value);
								preparedStatement
										.setObject(headerCounter, date);
							} else {
								preparedStatement.setObject(headerCounter,
										value);
							}
						} else {
							String headerType = headerTypes.get(headerNames
									.get(looper));
							if (headerType.contains("DATE")) {
								java.sql.Date date = getSqlDate(value);
								preparedStatement
										.setObject(headerCounter, date);
							} else {
								preparedStatement
										.setObject(headerCounter, "NA");
							}
						}
						headerCounter++;
					}
					int updatedCount = preparedStatement.executeUpdate();
					loggerInstance.logger.info("Affected rows = "
							+ updatedCount);
				}
				
				// check vendor duplication
				Cell vCode = row.getCell(2);
				String invoiceType = row.getCell(12).toString();

				// check if row is blank
				if ((!vCode.toString().equals(""))
						&& (invoiceType.equalsIgnoreCase("STANDARD"))) {
					vendorCode = Integer.parseInt(vCode.toString().replace(
							".0", ""));

					// check if duplicate vendor from database

					if (vendorList.size() != 0) {
						if (vendorList.contains(vendorCode)) {
							loggerInstance.logger.info("Duplicate Vendor");
						}
					}
					// if not duplicate in database
					else {

						// check if duplicate vendor in sheet
						if (!vendorIdList.contains(vendorCode)) {
							vendorIdList.add(Integer.parseInt(row.getCell(2)
									.getRawValue()));
							// adding data to entity
							vendorinfo.setVendorCode(Integer.parseInt(row
									.getCell(2).getRawValue()));
							vendorinfo.setVendorName(row.getCell(3).toString());
							vendorinfo.setPurchaseOrder(row.getCell(19)
									.toString().replace(".", ""));
							vendorinfo.setMinimumPayment(0);
							vendorinfo.setMaximumPayment(0);
							// insert data to invoiceinfo
							loggerInstance.logger.info("Insert to table"
									+ vendorCode);
							AddToDB.insertToVendorDb(vendorinfo, model);

						}
						// if duplicate in sheet
						else if (vendorIdList.contains(vendorCode)) {
							loggerInstance.logger
									.info("Duplicate vendor in file");
						}

					}
				}

				int flag = 0;
				// check invoice duplication
				Cell iCode = row.getCell(5);
				// check if row is blank
				if ((!iCode.toString().equals(""))
						&& (invoiceType.equalsIgnoreCase("STANDARD"))) {
					invoiceNum = iCode.toString();
					if (invoiceList.contains(invoiceNum)) {
						loggerInstance.logger.info("Duplicate Invoice Number");
						flag = 1;
					}

					// if not duplicate in database
					else {
						// check if duplicate vendor in sheet
						if (!invoiceIdList.contains(invoiceNum)) {
							invoiceIdList.add(row.getCell(5).toString());
							// adding data to entity

							// insert data to invoiceinfo
							loggerInstance.logger
									.info("Inserting in table for invoice number ");
							loggerInstance.logger.info(invoiceNum);
							
						}
						// if duplicate in sheet
						else if (invoiceIdList.contains(invoiceNum)) {
							loggerInstance.logger
									.info("Duplicate invoice Number in file");
							flag = 1;
						}
					}
				}
				// To do with madhavi
				
				if (flag == 1) {
					duplicateInvoiceList.add(row.getCell(5).toString());
					invalidinvoiceinfo.setInvoiceNum(row.getCell(5).toString());
					invalidinvoiceinfo.setInvoiceDate(row.getCell(8)
							.getDateCellValue());
					invalidinvoiceinfo.setInvoiceType(row.getCell(12)
							.toString());
					invalidinvoiceinfo.setInvoiceAmount(Float.parseFloat(row
							.getCell(15).toString().replace(".0", "")));
					invalidinvoiceinfo.setPrePaymentAmount(Integer.parseInt(row
							.getCell(17).toString().replace(".0", "")));
					invalidinvoiceinfo.setPaymentAmount(Float.parseFloat(row
							.getCell(16).toString().replace(".0", "")));
					invalidinvoiceinfo.setDescription(row.getCell(18)
							.toString());
					invalidinvoiceinfo.setBeneficiaryName(row.getCell(4)
							.toString());
					invalidinvoiceinfo.setInvoiceStatus("Unprocessed");
					invalidinvoiceinfo.setFilename(filename);
					invalidinvoiceinfo.setVendorId(Integer.parseInt(row
							.getCell(2).toString().replace(".0", "")));
					invalidinvoiceinfo.setVendorInvoiceNumber(row.getCell(10)
							.toString());
					invalidinvoiceinfo.setVendorInvoiceDate(row.getCell(11)
							.getDateCellValue());
					invalidinvoiceinfo.setMailStatus("N/A");
					// insert duplicate to invalidinvoiceinfo
					loggerInstance.logger
							.info("Duplicate invoice added to invalidInvoiceInfo table");
					msg += invalidinvoiceinfo.getVendorId() + "#";
					msg += invalidinvoiceinfo.getInvoiceNum() + "#";
					msg += invalidinvoiceinfo.getPaymentAmount() + "#";
					msg += invalidinvoiceinfo.getFilename() + "#";
					AddToDB.insertToDbInvalid(invalidinvoiceinfo, model);
					message = Messages.DUPLICATE_REQUEST;
				}

			}
			
					if (!duplicateInvoiceList.isEmpty()) {
				SendMailAtDuplicate.sendMail(createdBy, msg,
						duplicateInvoiceList);
			}

			// read the paymentsheet and add to aggregate sum table
			for (int i = 1; i <= firstSheet.getLastRowNum(); i++) { // get row
																	// data
				XSSFRow row = (XSSFRow) firstSheet.getRow(i);
				Cell vCode = row.getCell(2);
				String invoiceType = row.getCell(12).toString();
				invoiceNum = row.getCell(5).toString();
				// check if row is blank
				if ((!vCode.toString().equals(""))
						&& (invoiceType.equalsIgnoreCase("STANDARD"))
						&& (!duplicateInvoiceList.contains(invoiceNum))
						&& (!invoiceList.contains(invoiceNum))) {
					vendorCode = Integer.parseInt(vCode.toString().replace(
							".0", ""));
					ArrayList<String> aggregateList = new ArrayList<String>();
					if (!vendorMap.containsKey(vendorCode)) {
						payment = Double.parseDouble(row.getCell(16).toString()
								.replace(".0", ""));
						aggregateList.add(String.valueOf(vendorCode));
						aggregateList.add(String.valueOf(payment));
						aggregateList.add(row.getCell(3).toString());
						aggregateList.add(row.getCell(8).toString());
						aggregateList.add(row.getCell(9).toString());
						aggregateList.add(payment + " | "
								+ row.getCell(18).toString());
						vendorMap.put(vendorCode, aggregateList);
						vendorPaymentMap.put(vendorCode, payment);
						aggregateDescriptionMap.put(vendorCode, payment + " | "
								+ row.getCell(18).toString());
						loggerInstance.logger
								.info("Added vendor details in map "
										+ vendorCode + " " + payment);

					}
					// if duplicate in sheet
					else if (vendorMap.containsKey(vendorCode)) {
						payment1 = Double.parseDouble(row.getCell(16)
								.toString().replace(".0", ""));
						payment = vendorPaymentMap.get(vendorCode).intValue();
						String des = aggregateDescriptionMap.get(vendorCode);
						des = des + " $$ " + payment1 + " | "
								+ row.getCell(18).toString();

						aggregateDescriptionMap.put(vendorCode, des);
						vendorPaymentMap.put(vendorCode, payment + payment1);
						aggregateList.add(String.valueOf(vendorCode));
						aggregateList.add(String.valueOf(payment + payment1));
						aggregateList.add(row.getCell(3).toString());
						aggregateList.add(row.getCell(8).toString());
						aggregateList.add(row.getCell(9).toString());
						aggregateList.add(des);
						vendorMap.put(vendorCode, aggregateList);
						loggerInstance.logger
								.info("Added vendor details in existing map "
										+ vendorCode + " "
										+ (payment + payment1));
					}
				}
			}
			
			SimpleDateFormat inputFormat = new SimpleDateFormat("dd-MMM-yyyy");
			for (ArrayList<String> nextArray : vendorMap.values()) {
				aggregateinvoiceinfo.setVendorCode(Integer.parseInt(nextArray
						.get(0)));
				Date invoiceDate = inputFormat.parse(nextArray.get(3));
				Date invoiceCreataion = inputFormat.parse(nextArray.get(4));
				SimpleDateFormat outputFormat = new SimpleDateFormat(
						"dd-MMM-yyyy");

				aggregateinvoiceinfo.setPaymentAmount(Double
						.parseDouble(nextArray.get(1)));
				aggregateinvoiceinfo.setVendorName(nextArray.get(2));
				aggregateinvoiceinfo.setInvoiceDate(outputFormat
						.parse(outputFormat.format(invoiceDate)));
				aggregateinvoiceinfo.setInvoiceCreation(outputFormat
						.parse(outputFormat.format(invoiceCreataion)));
				aggregateinvoiceinfo.setInvoiceStatus("Unprocessed");
				aggregateinvoiceinfo.setPane("N/A");
				aggregateinvoiceinfo.setPendingPayment(0);
				aggregateinvoiceinfo.setRemark("N/A");
				aggregateinvoiceinfo.setMailStatus("N/A");

				aggregateinvoiceinfo.setDescription(nextArray.get(5));
				AddToDB.insertToSummingDb(aggregateinvoiceinfo,model);
				message = Messages.ADDTODB;
			}
		} catch (Exception e) {
			loggerInstance.logger.error(e);
			e.printStackTrace();
			message = "problem in adding to db";
		} finally {
			try {
				if (inputStream != null)
					inputStream.close();
			} catch (IOException e) {
				loggerInstance.logger.error(e);
			}
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {

				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {

				}
			}

		}
		entityManagerObject.close();
		loggerInstance.logger.info("Request processing result = " + message);
		return message;
	}


	private static void insertToDbInvalid(
			Invalidinvoiceinfo invalidinvoiceinfo, ModelMap model) {
		model.addAttribute("invoiceNum", invalidinvoiceinfo.getInvoiceNum());
		model.addAttribute("invoiceDate", invalidinvoiceinfo.getInvoiceDate());
		model.addAttribute("invoiceType", invalidinvoiceinfo.getInvoiceType());
		model.addAttribute("invoiceAmount",
				invalidinvoiceinfo.getInvoiceAmount());
		model.addAttribute("prePaymentAmount",
				invalidinvoiceinfo.getPrePaymentAmount());
		model.addAttribute("paymentAmount",
				invalidinvoiceinfo.getPaymentAmount());
		model.addAttribute("description", invalidinvoiceinfo.getDescription());
		model.addAttribute("beneficiaryName",
				invalidinvoiceinfo.getBeneficiaryName());
		model.addAttribute("invoiceStatus",
				invalidinvoiceinfo.getInvoiceStatus());
		model.addAttribute("filename", invalidinvoiceinfo.getFilename());
		model.addAttribute("vendorId", invalidinvoiceinfo.getVendorId());
		model.addAttribute("vendorInvoiceNumber",
				invalidinvoiceinfo.getVendorInvoiceNumber());
		model.addAttribute("vendorInvoiceDate",
				invalidinvoiceinfo.getVendorInvoiceDate());
		model.addAttribute("mailStatus", invalidinvoiceinfo.getMailStatus());
		EntityManager entityManagerObject = Database.getEntityManager();

		entityManagerObject.getTransaction().begin();
		entityManagerObject.persist(invalidinvoiceinfo);
		entityManagerObject.getTransaction().commit();
		entityManagerObject.close();

	}

	private static void insertToVendorDb(Vendorinfo vendorinfo, ModelMap model) {
		model.addAttribute("vendorCode", vendorinfo.getVendorCode());
		model.addAttribute("vendorName", vendorinfo.getVendorName());
		model.addAttribute("purchaseOrder", vendorinfo.getPurchaseOrder());
		model.addAttribute("maximumPayment", vendorinfo.getMaximumPayment());
		model.addAttribute("minimumPayment", vendorinfo.getMinimumPayment());

		EntityManager entityManagerObject = Database.getEntityManager();
		entityManagerObject.getTransaction().begin();
		entityManagerObject.persist(vendorinfo);
		entityManagerObject.getTransaction().commit();
		entityManagerObject.close();
	}

	private static void insertToSummingDb(
			Aggregateinvoiceinfo aggregateinvoiceinfo, ModelMap model) {
		model.addAttribute("vendorCode", aggregateinvoiceinfo.getVendorCode());
		model.addAttribute("vendorName", aggregateinvoiceinfo.getVendorName());
		model.addAttribute("paymentAmount",
				aggregateinvoiceinfo.getPaymentAmount());
		model.addAttribute("invoiceStatus",
				aggregateinvoiceinfo.getInvoiceStatus());
		model.addAttribute("pane", aggregateinvoiceinfo.getPane());
		model.addAttribute("invoiceDate", aggregateinvoiceinfo.getInvoiceDate());
		model.addAttribute("pendingPayment",
				aggregateinvoiceinfo.getPendingPayment());
		model.addAttribute("remark", aggregateinvoiceinfo.getRemark());
		model.addAttribute("mailStatus", aggregateinvoiceinfo.getMailStatus());
		model.addAttribute("description", aggregateinvoiceinfo.getDescription());
		model.addAttribute("invoiceCreation",
				aggregateinvoiceinfo.getInvoiceCreation());

		EntityManager entityManagerObject = Database.getEntityManager();
		entityManagerObject.getTransaction().begin();
		entityManagerObject.persist(aggregateinvoiceinfo);
		entityManagerObject.getTransaction().commit();
		entityManagerObject.close();
	}

	public static String getQueryString(String queryPrefix, String queryPostfix) {
		StringBuffer stringBuffer = new StringBuffer();
		// INSERT INTO
		// majorproject.invoiceinfo (id,Org,Profit Unit,Vendor Code,Vendor
		// Name,Beneficiary Name,Invoice Num,TDS section,TDS Category,Invoice
		// Date,Invoice Creation,Vendor Invoice Num,Vendor Invoice Date,Invoice
		// Type,Type Of Services,Currency,Invoice Amount,Payment
		// Amount,Prepayment Amount,PO Number)
		// VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);

		stringBuffer.append("INSERT INTO majorproject.invoiceinfo ("
				+ queryPrefix + ") VALUES(" + queryPostfix + ");");
		String result = stringBuffer.toString();
		loggerInstance.logger.info("Final query = " + result);
		
		return result;
	}

	public static String getQueryPostfix(int size) {
		loggerInstance.logger.info(size);
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < size; i++) {
			if (i == size - 1)
				stringBuffer.append("?");
			else
				stringBuffer.append("?,");
		}
		String result = stringBuffer.toString();
		loggerInstance.logger.info(result);
		return result;
	}

	public static String getQueryPrefix(ArrayList<String> headerNames) {
		StringBuffer stringBuffer = new StringBuffer();
		int counter = 0;
		for (String header : headerNames) {
			counter++;
			if (counter == headerNames.size())
				stringBuffer.append("`" + header + "`");
			else
				stringBuffer.append("`" + header + "`,");
		}

		String result = stringBuffer.toString();
		loggerInstance.logger.info("Query prefix formed = " + result);
		return result;
	}

	public static java.sql.Date getSqlDate(String startDate) {
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yyyy");
		java.util.Date date;
		java.sql.Date sqlDate = null;
		try {
			date = sdf1.parse(startDate);
			sqlDate = new java.sql.Date(date.getTime());

		} catch (ParseException e) {
			loggerInstance.logger
					.error("Exception in invoice date parsing" + e);
		}
		return sqlDate;
	}
}