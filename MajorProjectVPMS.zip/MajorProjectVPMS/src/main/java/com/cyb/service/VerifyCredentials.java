package com.cybage.service;

import java.util.Hashtable;



import javax.crypto.SecretKey;
import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;



public class VerifyCredentials {
	static DirContext ldapContext;
	public boolean validate(String username,byte[] encryptedPassword,HttpServletRequest request,SecretKey secretKey) 
	{
		try{			
			HttpSession session=request.getSession();
			session.setAttribute("username", username);
			
			return true;
		}catch(Exception e)
		{
			return false;
		}
	}
}
