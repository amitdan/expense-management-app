package com.cybage.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cybage.configuration.LoggerClass;
import com.cybage.configuration.PropertyClass;


public class ValidateExcelFile {
	 static ArrayList<String> header = new ArrayList<String>();
	 static HashMap<String,String> headerTypes = new HashMap<String, String>();
	public boolean validateExcelFile(String filename) {
		FileInputStream inputStream=null;
		boolean msg=true;
		int flag=1;
		validateFileByTableHeader();
		try {
			inputStream = new FileInputStream(new File(filename));
			Workbook workbook = new XSSFWorkbook(inputStream);
	        Sheet firstSheet = workbook.getSheetAt(0);	
	        XSSFRow row = (XSSFRow) firstSheet.getRow(0);
	        for(int k=1;k<15;k++){
	        	 Cell headerValue=row.getCell(k);
	        	
	        	 if(header.contains(headerValue.toString())){	        		 
	        		 flag=1;
	        	 }
	        	 else{
	        		 flag=0;    
	        		 break;
	             }
	        }
	        if(flag==1)
	        {
	        	return true;
	        }
	        else{
	        	return false;
	        }
	
		} catch (Exception e) {
			msg=false;			
		}
		finally{
			if(inputStream!=null){
			try {
				inputStream.close();
			} catch (IOException e) {
				LoggerClass.getLoggerInstance().logger.error(e);
			}
			}
		}
		return msg;
	}
	
	public static void validateFileByTableHeader(){
		 try {
			 PropertyClass property = new PropertyClass();
			Class.forName(property.getDatabaseDriver());
			Connection connection = DriverManager.getConnection(property.getDatabaseConnectionURL(), property.getDatabaseUsername(),property.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("SELECT * FROM majorproject.invoiceinfo;");
			 ResultSetMetaData rsMetaData = resultSet.getMetaData();
			    int numberOfColumns = rsMetaData.getColumnCount();

			    // get the column names; column indexes start from 1
			    for (int i = 2; i < numberOfColumns + 1; i++) {
			      String columnName = rsMetaData.getColumnName(i);
			      String typeOFColumn = rsMetaData.getColumnTypeName(i);
			      LoggerClass.logger.info(typeOFColumn);
			      LoggerClass.logger.info(columnName);
			      headerTypes.putIfAbsent(columnName, typeOFColumn);
			      if(!header.contains(columnName)){
			      header.add(columnName);
			      }
			    }
			
		} catch (ClassNotFoundException e) {
			LoggerClass.logger.error(e);
		} catch (IOException e) {
			LoggerClass.logger.error(e);
		} catch (SQLException e) {
			LoggerClass.logger.error(e);
		}
	}
	public static ArrayList getTableHeader(){
		validateFileByTableHeader();
		return header;
	}
	
	public static HashMap<String,String> getHeaderTypesMap(){
		validateFileByTableHeader();
		return headerTypes;
	}
}