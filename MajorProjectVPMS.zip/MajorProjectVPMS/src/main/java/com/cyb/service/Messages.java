package com.cybage.service;

public class Messages {
	public static final String INVALID_CREDENTIALS="Invalid Username or password";
	public static final String UNDEFINED_ROLES="You are not registered to the CybageVPMS";
	public static final String FILE_UPLOADED="File uploaded successfully";
	public static final String FILE_EXTENSIONS="Incorrect file format!! Acceptable file format is .xlsx";
	public static final String FILE_TEMPLATE="Invalid file template!! Please refer to valid file template";
	public static final String FILE_PROBLEM="Something went wrong ! Please re-upload the file!!";
	public static final String FILE_REPLACED="File replaced successfully";
	public static final String ADDTODB="File processed successfully";
	public static final String ADDTODBNOT="Unable to process file";
	public static final String PAYMENT_APPROVED="The invoice record has been APPROVED";
	public static final String PAYMENT_HELDBACK="The invoice record has been HELDBACKED";
	public static final String DUPLICATE_REQUEST="Requested file is duplicated!! Mail has been sent to uploader";
}
