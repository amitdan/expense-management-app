
package com.cyb.configuration;


import org.apache.log4j.*;

/**
 * The Class LoggerClass.
 @author akashpuri
 */
public class LoggerClass {
		
		/** The logger. */
		public static Logger logger;
		
		/**
		 * Instantiates a new logger class.
		 */
		private LoggerClass(){
			logger=Logger.getLogger(LoggerClass.class);
			PropertyConfigurator.configure(System.getProperty("user.dir")+"\\config\\log4j.properties");
		}
		
		/**
		 * Gets the logger instance.
		 *
		 * @return the logger instance
		 */
		public static LoggerClass getLoggerInstance(){
			return new LoggerClass();
		}
	}
