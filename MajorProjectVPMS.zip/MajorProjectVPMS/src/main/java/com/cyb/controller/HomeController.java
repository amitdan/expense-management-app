package com.cyb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mysql.jdbc.exceptions.jdbc4.MySQLNonTransientConnectionException;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	//Testing null pointer exception
	@RequestMapping(value = "/ShowDetail", method = RequestMethod.GET)
	public String showDetail() throws Exception {
		String exceptionOccured = "NULL_POINTER";
		if (exceptionOccured.equalsIgnoreCase("NULL_POINTER")) {
			throw new NullPointerException("NULL Pointer Exception Occured");
		}
		return "detail";
	}
	
	@ExceptionHandler(Exception.class)
	public String handleException() {
		return "errorPage";
	}
}