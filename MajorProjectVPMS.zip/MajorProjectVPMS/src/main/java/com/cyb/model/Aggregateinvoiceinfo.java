package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the aggregateinvoiceinfo database table.
 * 
 */
@Entity
@NamedQuery(name="Aggregateinvoiceinfo.findAll", query="SELECT a FROM Aggregateinvoiceinfo a")
public class Aggregateinvoiceinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private String description;

	@Temporal(TemporalType.DATE)
	private Date invoiceCreation;

	@Temporal(TemporalType.DATE)
	private Date invoiceDate;

	private String invoiceStatus;

	private String mailStatus;

	private String pane;

	private double paymentAmount;

	private double pendingPayment;

	private String remark;

	private int vendorCode;

	private String vendorName;

	public Aggregateinvoiceinfo() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getInvoiceCreation() {
		return this.invoiceCreation;
	}

	public void setInvoiceCreation(Date invoiceCreation) {
		this.invoiceCreation = invoiceCreation;
	}

	public Date getInvoiceDate() {
		return this.invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceStatus() {
		return this.invoiceStatus;
	}

	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}

	public String getMailStatus() {
		return this.mailStatus;
	}

	public void setMailStatus(String mailStatus) {
		this.mailStatus = mailStatus;
	}

	public String getPane() {
		return this.pane;
	}

	public void setPane(String pane) {
		this.pane = pane;
	}

	public double getPaymentAmount() {
		return this.paymentAmount;
	}

	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public double getPendingPayment() {
		return this.pendingPayment;
	}

	public void setPendingPayment(double pendingPayment) {
		this.pendingPayment = pendingPayment;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public int getVendorCode() {
		return this.vendorCode;
	}

	public void setVendorCode(int vendorCode) {
		this.vendorCode = vendorCode;
	}

	public String getVendorName() {
		return this.vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

}