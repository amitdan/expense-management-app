package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.math.BigInteger;


/**
 * The persistent class for the invoiceinfo database table.
 * 
 */
@Entity
@NamedQuery(name="Invoiceinfo.findAll", query="SELECT i FROM Invoiceinfo i")
public class Invoiceinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Column(name="`Beneficiary Name`")
	private String beneficiary_Name;

	private String currency;

	@Column(name="`Invoice Amount`")
	private int invoice_Amount;

	@Temporal(TemporalType.DATE)
	@Column(name="`Invoice Creation`")
	private Date invoice_Creation;

	@Temporal(TemporalType.DATE)
	@Column(name="`Invoice Date`")
	private Date invoice_Date;

	@Column(name="`Invoice Num`")
	private String invoice_Num;

	@Column(name="`Invoice Type`")
	private String invoice_Type;

	private int org;

	@Column(name="`Payment Amount`")
	private int payment_Amount;

	@Column(name="`PO Number`")
	private BigInteger PO_Number;

	@Column(name="`Prepayment Amount`")
	private int prepayment_Amount;

	@Column(name="`Profit Unit`")
	private String profit_Unit;

	@Column(name="`TDS Category`")
	private String TDS_Category;

	@Column(name="`TDS section`")
	private String TDS_section;

	@Column(name="`Type Of Services`")
	private String type_Of_Services;

	@Column(name="`Vendor Code`")
	private int vendor_Code;

	@Temporal(TemporalType.DATE)
	@Column(name="`Vendor Invoice Date`")
	private Date vendor_Invoice_Date;

	@Column(name="`Vendor Invoice Num`")
	private String vendor_Invoice_Num;

	@Column(name="`Vendor Name`")
	private String vendor_Name;

	public Invoiceinfo() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBeneficiary_Name() {
		return this.beneficiary_Name;
	}

	public void setBeneficiary_Name(String beneficiary_Name) {
		this.beneficiary_Name = beneficiary_Name;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public int getInvoice_Amount() {
		return this.invoice_Amount;
	}

	public void setInvoice_Amount(int invoice_Amount) {
		this.invoice_Amount = invoice_Amount;
	}

	public Date getInvoice_Creation() {
		return this.invoice_Creation;
	}

	public void setInvoice_Creation(Date invoice_Creation) {
		this.invoice_Creation = invoice_Creation;
	}

	public Date getInvoice_Date() {
		return this.invoice_Date;
	}

	public void setInvoice_Date(Date invoice_Date) {
		this.invoice_Date = invoice_Date;
	}

	public String getInvoice_Num() {
		return this.invoice_Num;
	}

	public void setInvoice_Num(String invoice_Num) {
		this.invoice_Num = invoice_Num;
	}

	public String getInvoice_Type() {
		return this.invoice_Type;
	}

	public void setInvoice_Type(String invoice_Type) {
		this.invoice_Type = invoice_Type;
	}

	public int getOrg() {
		return this.org;
	}

	public void setOrg(int org) {
		this.org = org;
	}

	public int getPayment_Amount() {
		return this.payment_Amount;
	}

	public void setPayment_Amount(int payment_Amount) {
		this.payment_Amount = payment_Amount;
	}

	public BigInteger getPO_Number() {
		return this.PO_Number;
	}

	public void setPO_Number(BigInteger PO_Number) {
		this.PO_Number = PO_Number;
	}

	public int getPrepayment_Amount() {
		return this.prepayment_Amount;
	}

	public void setPrepayment_Amount(int prepayment_Amount) {
		this.prepayment_Amount = prepayment_Amount;
	}

	public String getProfit_Unit() {
		return this.profit_Unit;
	}

	public void setProfit_Unit(String profit_Unit) {
		this.profit_Unit = profit_Unit;
	}

	public String getTDS_Category() {
		return this.TDS_Category;
	}

	public void setTDS_Category(String TDS_Category) {
		this.TDS_Category = TDS_Category;
	}

	public String getTDS_section() {
		return this.TDS_section;
	}

	public void setTDS_section(String TDS_section) {
		this.TDS_section = TDS_section;
	}

	public String getType_Of_Services() {
		return this.type_Of_Services;
	}

	public void setType_Of_Services(String type_Of_Services) {
		this.type_Of_Services = type_Of_Services;
	}

	public int getVendor_Code() {
		return this.vendor_Code;
	}

	public void setVendor_Code(int vendor_Code) {
		this.vendor_Code = vendor_Code;
	}

	public Date getVendor_Invoice_Date() {
		return this.vendor_Invoice_Date;
	}

	public void setVendor_Invoice_Date(Date vendor_Invoice_Date) {
		this.vendor_Invoice_Date = vendor_Invoice_Date;
	}

	public String getVendor_Invoice_Num() {
		return this.vendor_Invoice_Num;
	}

	public void setVendor_Invoice_Num(String vendor_Invoice_Num) {
		this.vendor_Invoice_Num = vendor_Invoice_Num;
	}

	public String getVendor_Name() {
		return this.vendor_Name;
	}

	public void setVendor_Name(String vendor_Name) {
		this.vendor_Name = vendor_Name;
	}

}