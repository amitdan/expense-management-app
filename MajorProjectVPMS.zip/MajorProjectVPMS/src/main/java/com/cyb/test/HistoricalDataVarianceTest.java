package com.cybage.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cybage.service.HistoricalDataVarianceCriteria;

public class HistoricalDataVarianceTest {
	
	HistoricalDataVarianceCriteria historicalDataVarianceCriteria=new HistoricalDataVarianceCriteria();

	@Test
	public void testapplyCriteria() {
		
		int percentVariance=10;
		int vendorCode=200596;
		int paymentAmount=1000;
		
		
		//assertNotNull(historicalDataVarianceCriteria.applyCriteria(percentVariance, vendorCode, paymentAmount));	

		
	}

}