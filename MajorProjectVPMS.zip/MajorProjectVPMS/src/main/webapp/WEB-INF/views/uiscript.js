// create the module and name it scotchApp
	var scotchApp = angular.module('userApp', ["ngRoute"]);

	// configure our routes
	scotchApp.config(function($routeProvider) {
		$routeProvider
			// route for the home page
			
			.when("/home", {
				template : "<h3>Philanthropy</h3><p>The company operates a development charity, CybageAsha[8] founded in October 2003, which runs programs for rural development, treatment of alcohol addiction, social welfare, and environmental projects. It also operates the Khushboo Charitable Trust (also known as CybageKhushboo), which aims to help poorer students with scholarship programs and career counseling.[9] These activities are run by company staff volunteers, sometimes in partnership with other NGOs[which?].</p>"
			})
			// route for the about page
			.when("/viewT", {
				template : "<h3>Philanthropy</h3><p>The company operates a development charity, CybageAsha[8] founded in October 2003, which runs programs for rural development, treatment of alcohol addiction, social welfare, and environmental projects. It also operates the Khushboo Charitable Trust (also known as CybageKhushboo), which aims to help poorer students with scholarship programs and career counseling.[9] These activities are run by company staff volunteers, sometimes in partnership with other NGOs[which?].</p>"
			})
			.when("/heldback", {
                templateUrl : 'views/login.jsp',
                controller  : 'mainController'
				
			})
			
			.when("/login", {
				templateUrl : 'pages/login.html',
				controller  : 'mainController'
			})
			// route for the contact page
			
	});
	function openPage(pageURL)
	 {
	 window.location.href = pageURL;
	 }

	// create the controller and inject Angular's $scope
	scotchApp.controller('mainController', function($scope) {
		alert("aaaaaaaa")
		// create a message to display in our view
		$scope.message = 'Everyone come and see how good I look!';
	});

	scotchApp.controller('aboutController', function($scope) {
		$scope.message = 'Look! I am an about page.';
	});

	scotchApp.controller('contactController', function($scope) {
		$scope.message = 'Contact us! JK. This is just a demo.';
	});